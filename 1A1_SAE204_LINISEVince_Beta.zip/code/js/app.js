const { animate, scroll, stagger, inView } = Motion;
const windowHeight = window.innerHeight;

lucide.createIcons();
