# Mise a jour version beta

Changelog des corrections depuis le test effectué par LEO FEREZOU.

### Changements

- Ajout d'un bouton d'accessibilité permettant de mettre en pause l'animation de l'écran d'accueil
- Amélioration du focus de la navigation au clavier
- Suppression de liens inaccessibles
- Ajustement des marges et du responsive sur les ecrans de moyenne taille et les téléphones portables
- Amélioration du contraste en changeant les couleurs des textes sur fonds colorés
